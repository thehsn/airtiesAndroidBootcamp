package com.example.fooddeliveryapp.fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.viewModels
import com.example.fooddeliveryapp.R
import com.example.fooddeliveryapp.adapter.UrunlerAdapter
import com.example.fooddeliveryapp.databinding.FragmentFavorilerBinding
import com.example.fooddeliveryapp.entity.Restoranlar
import com.example.fooddeliveryapp.viewmodel.FavorilerFragmentViewModel


class FavorilerFragment : Fragment() {
    private lateinit var tasarim:FragmentFavorilerBinding
    private lateinit var viewModel:FavorilerFragmentViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        tasarim = DataBindingUtil.inflate(inflater, R.layout.fragment_favoriler, container, false)

        viewModel.favorilerListesi.observe(viewLifecycleOwner){
            tasarim.adapter = UrunlerAdapter(requireContext(),it,this, viewModel)
        }


        return tasarim.root
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val tempViewModel:FavorilerFragmentViewModel by viewModels()
        viewModel = tempViewModel
    }
}