package com.example.fooddeliveryapp.adapter

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.RecyclerView
import com.example.fooddeliveryapp.R
import com.example.fooddeliveryapp.databinding.CardRestoranBinding
import com.example.fooddeliveryapp.databinding.CardTasarimBinding
import com.example.fooddeliveryapp.entity.Favoriler
import com.example.fooddeliveryapp.entity.Restoranlar
import com.example.fooddeliveryapp.fragment.FavorilerFragment
import com.example.fooddeliveryapp.fragment.RestoranFragment
import com.example.fooddeliveryapp.setSafeOnClickListener
import com.example.fooddeliveryapp.viewmodel.FavorilerFragmentViewModel
import com.squareup.picasso.Picasso

class UrunlerAdapter(var mContext: Context,
                     var favorilerListesi:List<Favoriler>,
                     val activity: FavorilerFragment,
                     var viewModel:FavorilerFragmentViewModel)

    : RecyclerView.Adapter<UrunlerAdapter.CardTasarimTutucu>() {

    inner class CardTasarimTutucu(tasarim:CardRestoranBinding) : RecyclerView.ViewHolder(tasarim.root){
        var tasarim:CardRestoranBinding
        init {
            this.tasarim = tasarim
        }
    }


    override fun getItemCount(): Int {
        var counter = 0
        for(fav in favorilerListesi){
            if (fav.type.equals("restoran")){
                counter++
            }
        }
        Log.e("fav size: ", counter.toString())
        return counter
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CardTasarimTutucu {
        val layoutInflater = LayoutInflater.from(mContext)
        val tasarim: CardRestoranBinding = DataBindingUtil.inflate(
            layoutInflater,
            R.layout.card_restoran, parent, false
        )

        return CardTasarimTutucu(tasarim)
    }

    override fun onBindViewHolder(holder: CardTasarimTutucu, position: Int) {
        val t = holder.tasarim
        val restoranlar = ArrayList<Restoranlar>()

        //fav listesinde olan restoranlari bul
        for(fav in favorilerListesi){
            if (fav.favori_database_type.equals("restoran")){
                viewModel.restoranAra(fav.favori_yemek_ad!!)
            }
        }

        viewModel.restoranlarListesi.observe(activity, Observer{
            Log.e("restoran boyut: ", it.size.toString())

            val restoran = it.get(position)
            if (restoran != null){
                t.restoranNesnesi = restoran
                resimGoster(restoran.restoran_resim_adi!!, t)
                Log.e("resimadi:" , restoran.restoran_resim_adi!!)
            }
        })

        t.floatingActionButtonFavori.setSafeOnClickListener {
            viewModel.restoranaAitFavorileriSil(t.textViewRestoranAd.text.toString(), viewModel.getUser())
        }


    }

    fun resimGoster(resimAdi:String, tasarim: CardRestoranBinding){
        Picasso.get()
            .load(resimAdi)
            //.resize(512,512)
            .rotate(0f)
            .placeholder(R.drawable.placeholder)
            .error(R.drawable.hata)
            .into(tasarim.imageViewRestoranResim)
    }

}