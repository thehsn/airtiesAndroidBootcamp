package com.example.fooddeliveryapp.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.example.fooddeliveryapp.R
import com.example.fooddeliveryapp.databinding.CardRestoranBinding
import com.example.fooddeliveryapp.databinding.CardTasarimBinding
import com.example.fooddeliveryapp.databinding.CardTasarimKampanyaBinding
import com.example.fooddeliveryapp.entity.FirebaseYemekler
import com.example.fooddeliveryapp.entity.Kampanyalar
import com.example.fooddeliveryapp.fragment.RestoranFragment
import com.example.fooddeliveryapp.viewmodel.RestoranFragmentViewModel
import com.example.kisileruygulamasi.viewmodel.AnasayfaFragmentViewModel

class FirebaseYemeklerAdapter(var mContext: Context, // we need for inflating our layout
                              var firebaseYemeklerListesi:List<FirebaseYemekler>, // livedata
                              var viewModel: RestoranFragmentViewModel,
                              val activity: RestoranFragment
)
    : RecyclerView.Adapter<FirebaseYemeklerAdapter.CardTasarimTutucu>() {

    inner class CardTasarimTutucu(tasarim: CardTasarimBinding) : RecyclerView.ViewHolder(tasarim.root) {

        var tasarim: CardTasarimBinding

        init {
            this.tasarim = tasarim
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CardTasarimTutucu {
        val layoutInflater = LayoutInflater.from(mContext)

        val tasarim: CardTasarimBinding = DataBindingUtil.inflate(
            layoutInflater,
            R.layout.card_tasarim, parent, false
        )
        return CardTasarimTutucu(tasarim)
    }

    override fun onBindViewHolder(holder: CardTasarimTutucu, position: Int) {
        val t = holder.tasarim
        val firebaseYemek = firebaseYemeklerListesi.get(position)
        t.textUrunAd.text = firebaseYemek.yemek_ad.toString()
        t.textUrunFiyat.text = firebaseYemek.yemek_fiyat.toString()
    }

    override fun getItemCount(): Int {
        return firebaseYemeklerListesi.size
    }


}