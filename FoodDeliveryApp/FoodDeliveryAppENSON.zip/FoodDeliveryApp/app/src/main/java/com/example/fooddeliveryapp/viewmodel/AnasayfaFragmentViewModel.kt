package com.example.kisileruygulamasi.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import com.example.fooddeliveryapp.entity.Favoriler
import com.example.fooddeliveryapp.entity.Kampanyalar
import com.example.fooddeliveryapp.entity.Restoranlar
import com.example.fooddeliveryapp.entity.Yemekler
import com.example.fooddeliveryapp.repo.FavorilerDaoRepository
import com.example.fooddeliveryapp.repo.KampanyalarDaoRepository
import com.example.fooddeliveryapp.repo.RestoranlarDaoRepository
import com.example.fooddeliveryapp.repo.YemeklerDaoRepository

class AnasayfaFragmentViewModel(private val state: SavedStateHandle) : ViewModel() {


    val krepo = KampanyalarDaoRepository()
    var kampanyalarListesi = MutableLiveData<List<Kampanyalar>>()

    val frepo = FavorilerDaoRepository()
    var favorilerListesi = MutableLiveData<List<Favoriler>>()

    var restoranRepo = RestoranlarDaoRepository()
    var restoranlarListesi = MutableLiveData<List<Restoranlar>>()

    private lateinit var user:String

    init {
        user = state.get<String>("user_id").toString()

        kampanyalariYukle()
        kampanyalarListesi = krepo.kampanyalariGetir()

        favorileriYukle()
        favorilerListesi = frepo.favoriListesiniGetir()

        restoranlariYukle()
        restoranlarListesi = restoranRepo.restoranlariGetir()

    }

    fun getUser():String{
        return user
    }

    fun kampanyalariYukle(){
        krepo.tumKampanyalariAl()
    }

//----------------------- firebase --------------------------------

    fun favorileriYukle(){
        frepo.tumFavorileriAl()
    }

    fun favoridenSil(favori_id:String){
        frepo.favoriSil(favori_id)
    }

    fun favoriEkle(database_type:String, yemek_ad: String, type:String, restoran:String, user:String){
        frepo.favoriEkle(database_type,yemek_ad, type, restoran, user)
    }

    fun restoranaAitFavorileriSil(restoran:String, user:String){
        frepo.restoranaAitFavorileriSil(restoran, user)
    }

    //restoranlar

    fun restoranlariYukle(){
        restoranRepo.tumRestoranlariGetir()
    }
}